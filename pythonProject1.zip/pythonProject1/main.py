import pygame
from setting import *
from levl import Level
from overworld import Owervorld
from ui import UI


class Game:
    def __init__(self):
        self.max_levl = 1
        self.coins = 0

        self.overworld = Owervorld(0, self.max_levl, screen, self.creat_levl)
        self.stats = 'overworld'

        self.ui = UI(screen)

    def creat_levl(self, curren_level):
        self.level = Level(curren_level, screen, self.creat_overworld, self.change)
        self.stats = 'level'

    def creat_overworld(self, cur_l, new_max_l):
        if new_max_l > self.max_levl:
            self.max_levl = new_max_l
        self.overworld = Owervorld(cur_l, self.max_levl, screen, self.creat_levl)
        self.stats = 'overworld'

    def change(self, sum):
        self.coins += sum
    def run(self):
        if self.stats == 'overworld':
            self.overworld.run()
            font = pygame.font.Font(None, 36)
            lev_1 = font.render("Level 1", True, 'black')
            screen.blit(lev_1, (80, 300))
            lev_2 = font.render("Level 2", True, 'black')
            screen.blit(lev_2, (590, 250))
            lev_3 = font.render("Level 3", True, 'black')
            screen.blit(lev_3, (1000, 300))

        else:
            self.level.run()
            self.ui.show_coin(self.coins)

if __name__ == '__main__':
    pygame.init()
    screen = pygame.display.set_mode(size)
    clock = pygame.time.Clock()
    game = Game()

    while pygame.event.wait().type != pygame.QUIT:
        screen.fill('grey')
        game.run()
        pygame.display.update()
        clock.tick(60)
    pygame.quit()
