import pygame

class UI:
    def __init__(self, surface):
        self.display_surf = surface
        self.coin = pygame.image.load('image_for_map/coin.png')
        self.coin_rect = self.coin.get_rect(topleft=(20, 10))
        self.font = pygame.font.Font(None, 40)

    def show_coin(self, sum):
        self.display_surf.blit(self.coin, self.coin_rect)
        coin_surf = self.font.render(str(sum) , False, 'black')
        coin_rect = coin_surf.get_rect(midleft=(self.coin_rect.right + 5, self.coin_rect.centery))
        self.display_surf.blit(coin_surf, coin_rect)


