import pygame
from support import csv_layout, cut_graphics
from setting import tile_size, size
from tile import StaticTile
from player import Player
from particles import ParticleEffect
from level_danue import levels


class Level:
    def __init__(self,curren_level, surface, creat_overworld, cange_coin):
        self.display_surf = surface
        self.w_shift = 0
        self.current_x = None

        self.creat_overworld = creat_overworld
        self.cur_levl = curren_level
        level_dat = levels[self.cur_levl]
        self.new_max_levl = level_dat['unklock']


        player_layout = csv_layout(level_dat['player'])
        self.player = pygame.sprite.GroupSingle()
        self.goal = pygame.sprite.GroupSingle()
        self.player_setup(player_layout)

        self.cange_coin = cange_coin

        self.dust_sprite = pygame.sprite.GroupSingle()
        self.player_on_ground = False

        terrain_layout = csv_layout(level_dat['terrain'])
        self.terrain_sprite = self.creat_til_grop(terrain_layout, 'terrain')

        money_layout = csv_layout(level_dat['money'])
        self.money_sprite = self.creat_til_grop(money_layout, 'money')

    def creat_til_grop(self, layout, tpu):
        sprit_grop = pygame.sprite.Group()
        for row_ind, row in enumerate(layout):
            for col_ind, col in enumerate(row):
                if col != '-1':
                    x = col_ind * tile_size
                    y = row_ind * tile_size
                    if tpu == 'terrain':
                        terrain_list = cut_graphics('image_for_map/terrain_tiles.png')
                        tile_surface = terrain_list[int(col)]
                        sprite = StaticTile(tile_size, x, y, tile_surface)
                    if tpu == 'money':
                        money_list = cut_graphics('image_for_map/coin_tiles.png')
                        tile_surface = money_list[int(col)]
                        sprite = StaticTile(tile_size, x, y, tile_surface)
                    sprit_grop.add(sprite)
        return sprit_grop

    def player_setup(self, layout):
        for row_ind, row in enumerate(layout):
            for col_ind, col in enumerate(row):
                x = col_ind * tile_size
                y = row_ind * tile_size
                if col == '0':
                    sprite = Player((x, y), self.display_surf, self.create_jump_particles)
                    self.player.add(sprite)
                if col == '1':
                    frend_surfase = pygame.image.load('image_for_map/saty.png').convert_alpha()
                    sprite = StaticTile(tile_size, x, y, frend_surfase)
                    self.goal.add(sprite)

    def create_jump_particles(self, pos):
        if self.player.sprite.facing_right:
            pos -= pygame.math.Vector2(10, 5)
        else:
            pos += pygame.math.Vector2(10, -5)
        jump_particle_sprite = ParticleEffect(pos, 'jump')
        self.dust_sprite.add(jump_particle_sprite)

    def horizontal_movement_collision(self):
        player = self.player.sprite
        player.rect.x += player.direction.x * player.speed

        for sprite in self.terrain_sprite.sprites():
            if sprite.rect.colliderect(player.rect):
                if player.direction.x < 0:
                    player.rect.left = sprite.rect.right
                    player.on_left = True
                    self.current_x = player.rect.left
                elif player.direction.x > 0:
                    player.rect.right = sprite.rect.left
                    player.on_right = True
                    self.current_x = player.rect.right

        if player.on_left and (player.rect.left < self.current_x or player.direction.x >= 0):
            player.on_left = False
        if player.on_right and (player.rect.right > self.current_x or player.direction.x <= 0):
            player.on_right = False

    def vertical_movement_collision(self):
        player = self.player.sprite
        player.apply_gravity()

        for sprite in self.terrain_sprite.sprites():
            if sprite.rect.colliderect(player.rect):
                if player.direction.y > 0:
                    player.rect.bottom = sprite.rect.top
                    player.direction.y = 0
                    player.on_ground = True
                elif player.direction.y < 0:
                    player.rect.top = sprite.rect.bottom
                    player.direction.y = 0
                    player.on_ceiling = True

        if player.on_ground and player.direction.y < 0 or player.direction.y > 1:
            player.on_ground = False
        if player.on_ceiling and player.direction.y > 0.1:
            player.on_ceiling = False

    def scroll_x(self):
        player = self.player.sprite
        player_x = player.rect.centerx
        direction_x = player.direction.x

        if player_x < size[0] / 4 and direction_x < 0:
            self.w_shift = 8
            player.speed = 0
        elif player_x > size[0] - (size[0] / 4) and direction_x > 0:
            self.w_shift = -8
            player.speed = 0
        else:
            self.w_shift = 0
            player.speed = 8

    def get_player_on_ground(self):
        if self.player.sprite.on_ground:
            self.player_on_ground = True
        else:
            self.player_on_ground = False

    def create_landing_dust(self):
        if not self.player_on_ground and self.player.sprite.on_ground and not self.dust_sprite.sprites():
            if self.player.sprite.facing_right:
                offset = pygame.math.Vector2(10, 15)
            else:
                offset = pygame.math.Vector2(-10, 15)
            fall_dust_particle = ParticleEffect(self.player.sprite.rect.midbottom - offset, 'land')
            self.dust_sprite.add(fall_dust_particle)

    def check_death(self):
        if self.player.sprite.rect.top > size[1]:
            self.creat_overworld(self.cur_levl, 0)
    def check_win(self):
        if pygame.sprite.spritecollide(self.player.sprite, self.goal, False):
            self.creat_overworld(self.cur_levl, self.new_max_levl)

    def check_coin(self):
        collided_coin = pygame.sprite.spritecollide(self.player.sprite, self.money_sprite, True)
        if collided_coin:
            for c in collided_coin:
                self.cange_coin(1)
    def run(self):
        self.terrain_sprite.draw(self.display_surf)
        self.terrain_sprite.update(self.w_shift)

        self.money_sprite.draw(self.display_surf)
        self.money_sprite.update(self.w_shift)

        self.goal.update(self.w_shift)
        self.goal.draw(self.display_surf)

        self.dust_sprite.update(self.w_shift)
        self.dust_sprite.draw(self.display_surf)

        self.player.update()
        self.player.draw(self.display_surf)

        self.horizontal_movement_collision()
        self.get_player_on_ground()
        self.vertical_movement_collision()
        self.create_landing_dust()
        self.scroll_x()

        self.check_death()
        self.check_win()
        self.check_coin()