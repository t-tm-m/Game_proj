import pygame
from support import import_folder
from level_danue import levels


class Node(pygame.sprite.Sprite):
    def __init__(self, pos, stats, icon_speed):
        super().__init__()
        self.image = pygame.Surface((150, 100))
        if stats == 'available':
            self.image.fill('#3E4149')
        else:
            self.image.fill('#C9D6DF')
        self.rect = self.image.get_rect(center=pos)

        self.dir_zone = pygame.Rect(self.rect.centerx - (icon_speed / 2), self.rect.centery - (icon_speed / 2), icon_speed, icon_speed)

class Icon(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.pos = pos
        self.image = pygame.image.load('image_for_map/saty.png').convert_alpha()
        self.rect = self.image.get_rect(center=pos)

    def update(self):
        self.rect.center = self.pos

class Owervorld:
    def __init__(self, start_lev, max_lev, surfase, creat_levl):
        self.display_surf = surfase
        self.max_levl = max_lev
        self.cur_levl = start_lev
        self.creat_levl =creat_levl

        self.moving = False
        self.move_direction = pygame.math.Vector2(0, 0)
        self.speed = 8

        self.setup_nodes()
        self.setup_icon()

    def setup_nodes(self):
        self.nods = pygame.sprite.Group()

        for ind, n_data in enumerate(levels.values()):
            if ind <= self.max_levl:
                nod_sprite = Node(n_data['node_pos'], 'available', self.speed)
            else:
                nod_sprite = Node(n_data['node_pos'], 'locked', self.speed)
            self.nods.add(nod_sprite)

    def draw_paths(self):
        points = [i['node_pos'] for ind, i in enumerate(levels.values()) if ind <= self.max_levl]
        pygame.draw.lines(self.display_surf, '#444F5A', False, points, 6)

    def setup_icon(self):
        self.icon = pygame.sprite.GroupSingle()
        icon_sprite = Icon(self.nods.sprites()[self.cur_levl].rect.center)
        self.icon.add(icon_sprite)

    def input(self):
        keys = pygame.key.get_pressed()
        if not self.moving:
            if keys[pygame.K_RIGHT] and self.cur_levl < self.max_levl:
                self.move_direction = self.get_mov_dat('next')
                self.cur_levl += 1
                self.moving = True
            elif keys[pygame.K_LEFT] and self.cur_levl > 0:
                self.move_direction = self.get_mov_dat('previous')
                self.cur_levl -= 1
                self.moving = True
            elif keys[pygame.K_SPACE]:
                self.creat_levl(self.cur_levl)

    def get_mov_dat(self, target):
        start = pygame.math.Vector2(self.nods.sprites()[self.cur_levl].rect.center)
        if target == 'next':
            end = pygame.math.Vector2(self.nods.sprites()[self.cur_levl + 1].rect.center)
        else:
            end = pygame.math.Vector2(self.nods.sprites()[self.cur_levl - 1].rect.center)
        return (end - start).normalize()
    def update_icon(self):
        if self.moving and self.move_direction:
            self.icon.sprite.pos += self.move_direction * self.speed
            target_node = self.nods.sprites()[self.cur_levl]
            if target_node.dir_zone.collidepoint(self.icon.sprite.pos):
                self.moving = False
                self.move_direction = pygame.math.Vector2(0, 0)
    def run(self):
        self.input()
        self.update_icon()
        self.icon.update()
        self.draw_paths()
        self.nods.draw(self.display_surf)
        self.icon.draw(self.display_surf)

