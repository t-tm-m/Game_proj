vertical_numer = 11
tile_size = 64

size = width, height = 1200, vertical_numer * tile_size
