level_0 = {'terrain': 'levels/0/map_terrain_0.csv',
           'money': 'levels/0/map_many_0.csv',
           'player': 'levels/0/map_player_0.csv',
           'node_pos': (110, 400),
           'unklock': 2}

level_1 = {'terrain': 'levels/1/map_terrain_1.csv',
           'money': 'levels/1/map_money_1.csv',
           'player': 'levels/1/map_player_1.csv',
           'node_pos': (610, 350),
           'unklock': 3}

level_2 = {'terrain': 'levels/2/map_terrain_3.csv',
           'money': 'levels/2/map_money_3.csv',
           'player': 'levels/2/map_player_3.csv',
           'node_pos': (1050, 400),
           'unklock': 3}

levels = {0: level_0,
          1: level_1,
          2: level_2}
